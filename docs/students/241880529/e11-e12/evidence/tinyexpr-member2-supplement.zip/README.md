# TinyExpr MDFixer 成员 2 补交

源码和复跑说明在 `tynacity/devops-e8-e10-b08` 的 `student/241880529/e11-e12` 分支。源码提交 `9b672378477f86d7e65dcf4a90bfc49e4ecf7e69`，入口 `labs/e11e12/tinyexpr_repair.py`。正反输入为 `fixtures/e11e12/tinyexpr-md/accept.json` 和 `reject-incomplete.json`。请参照仓库 `docs/students/241880529/e11-e12/TinyExpr适配.md` 的命令。

- `provenance.json` 关联源码、原有运行、测试命令与退出码、报告哈希及审计复跑环境。
- `tests/` 保留 18 项和 22 项测试的完整原始输出，`tests/original/` 为此前留存的两组输出。
- `baseline/tinyexpr-baseline-probe-20261110/` 是生成固定报告前的动态检测原件，包含 trace、声明图、实际图及 Make 数据库。
- `source-audit/accept/`、`source-audit/reject/` 是同一 DRAFT 镜像的补采证据。各有命令、退出码、原输入仓库的前后 Git 状态、目标副本状态和 23 个文件的 SHA-256 对照。`target_checkout_sha256` 取自检出提交的 Git 对象。目标副本与独立验证沙箱分开。
- `audit-rerun.py` 是补采工具，可从仓库根目录运行，参数依次为实际 DRAFT 镜像 ID 与新输出目录。Windows 直接调用 Docker Desktop，按挂载所有者使用容器 UID 0。Linux 使用宿主 UID/GID。

此前的候选和完整运行产物沿用原交付。两份固定输入均来自本地 BuildChecker，正式 A→B 联调使用 A 组实际报告与生产清单。归档文件可用 `sha256sum -c SHA256SUMS.txt` 校验。
