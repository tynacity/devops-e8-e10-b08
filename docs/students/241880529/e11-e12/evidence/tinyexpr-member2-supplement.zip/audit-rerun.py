"""Capture source protection independently of the MDFixer verdict."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

PROBE = r'''
import hashlib, json, subprocess
from pathlib import Path

def git(*args):
    return subprocess.check_output(['git', *args])

def sha(content):
    return hashlib.sha256(content).hexdigest()

files = {}
for name in git('ls-files', '-z').decode().split('\0')[:-1]:
    head = git('show', 'HEAD:' + name)
    raw = Path(name).read_bytes()
    files[name] = {'head_sha256': sha(head), 'raw_sha256': sha(raw),
                   'crlf_to_lf_sha256': sha(raw.replace(b'\r\n', b'\n'))}
print(json.dumps({'head': git('rev-parse', 'HEAD').decode().strip(), 'files': files,
                  'status': git('status', '--porcelain=v1').decode(),
                  'diff_summary': git('diff', '--summary').decode(),
                  'diff_numstat': git('diff', '--numstat').decode(),
                  'diff_autocrlf_numstat': git('-c', 'core.autocrlf=true', 'diff', '--numstat').decode(),
                  'ls_files_eol': git('ls-files', '--eol').decode()}, indent=2))
'''

root = Path.cwd()
image, out_name = sys.argv[1:]
out = Path(out_name)
out.mkdir(parents=True, exist_ok=False)
source = Path('data/real-project')
inputs = Path('fixtures/e11e12/tinyexpr-md')
target = 'db16775c83f90ead79255cc124d2a5f62f58a3b3'
user = '0:0' if os.name == 'nt' else f'{os.getuid()}:{os.getgid()}'


def snapshot(repo, evidence, label):
    argv = ['docker', 'run', '--rm', '--network', 'none',
            '--user', user, '-e', 'HOME=/tmp',
            '-e', 'GIT_OPTIONAL_LOCKS=0', '-v', f'{root}:/course:ro',
            '-w', '/course/' + repo.as_posix(), '--entrypoint', 'python3', image, '-c', PROBE]
    raw = subprocess.check_output(argv)
    (evidence / (label + '.json')).write_bytes(raw)
    data = json.loads(raw)
    (evidence / (label + '.log')).write_text(data['status'], encoding='utf-8')
    assert data['head'] == target
    return data


for label, fixture, code in (('accept', 'accept.json', 0), ('reject', 'reject-incomplete.json', 1)):
    evidence = out / label
    evidence.mkdir()
    report = inputs / fixture
    report_sha = hashlib.sha256(report.read_bytes()).hexdigest()
    before = snapshot(source, evidence, 'source-before')
    run = evidence / 'run'
    argv = ['docker', 'run', '--rm', '--network', 'none', '--cap-add', 'SYS_PTRACE',
            '--user', user, '-e', 'HOME=/tmp', '-v', f'{root}:/course', '-w', '/course',
            '--entrypoint', 'python3', image, 'labs/e11e12/tinyexpr_repair.py',
            '--repo', '/course/' + source.as_posix(), '--target', target,
            '--report', '/course/' + report.as_posix(), '--report-sha256', report_sha,
            '--out', '/course/' + run.as_posix()]
    proc = subprocess.run(argv, capture_output=True)
    (evidence / 'command.json').write_text(json.dumps({'argv': argv, 'exit_code': proc.returncode}, indent=2) + '\n')
    (evidence / 'stdout.log').write_bytes(proc.stdout)
    (evidence / 'stderr.log').write_bytes(proc.stderr)
    after = snapshot(source, evidence, 'source-after')
    patched = snapshot(run / 'target-project', evidence, 'target-after')
    assert proc.returncode == code
    assert before == after
    assert before['files'].keys() == patched['files'].keys()
    assert all(f['head_sha256'] in (f['raw_sha256'], f['crlf_to_lf_sha256'])
               for f in before['files'].values())
    assert not before['diff_summary']
    result = json.loads((run / 'result.json').read_bytes())
    verdict = json.loads((run / 'validation/validation.json').read_bytes())
    assert result['input']['sha256'] == report_sha
    changed = [name for name, f in patched['files'].items() if f['raw_sha256'] != f['head_sha256']]
    if code == 0:
        assert changed == ['Makefile'] and verdict['accepted'] and all(verdict['checks'].values())
    else:
        assert not changed and verdict['rollback'] and verdict['source_unchanged']
        assert result['error']['code'] == 'REPAIR_REJECTED'
    table = ['file\tinput_before_sha256\tinput_after_sha256\ttarget_checkout_sha256\ttarget_after_sha256']
    for name, f in before['files'].items():
        table.append('\t'.join([name, f['raw_sha256'], after['files'][name]['raw_sha256'],
                                f['head_sha256'], patched['files'][name]['raw_sha256']]))
    (evidence / 'source-hashes.tsv').write_text('\n'.join(table) + '\n', encoding='utf-8')
    print(label, 'exit', code, 'changed target files:', changed)
