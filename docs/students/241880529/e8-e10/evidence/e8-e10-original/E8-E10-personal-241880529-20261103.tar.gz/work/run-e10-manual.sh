#!/usr/bin/env bash
set -euo pipefail
cd /root/241880529/github-e8-e10-20261103
mkdir -p work
exec > >(tee work/e10-personal-session.log) 2>&1
source work/course/classroom_helpers.sh
lab_ready
lab_new_run e10 B
trap 'code=$?; printf "{\"exit_code\":%s}\n" "$code" > "$OUT/session-exit.json"' EXIT
printf 'PERSONAL_OUT=%s\n' "$OUT"
sha256sum labs/e8e10/lab.py labs/e8e10/test_profile.py > "$OUT/source.sha256"
git branch --show-current > "$OUT/student-branch.txt"

printf 'MANUAL_SECTION=1\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import fixture
out=Path(sys.argv[1]); fixture(out/'project')
print('CREATED',out/'project')
PY
printf 'SECTION_1_FINISHED\n'

printf 'MANUAL_SECTION=2\n'
pwd
cat "$OUT/student-source-commit.txt"
cat "$OUT/project/Makefile"
cat "$OUT/project/main.c"
cat "$OUT/project/config.h"
cat "$OUT/project/helper.c"
git -C "$OUT/project" log -1 --oneline
printf 'SECTION_2_FINISHED\n'

printf 'MANUAL_SECTION=3\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import scan,save
out=Path(sys.argv[1]);r=scan(out/'project')
save(out/'fixed-md-report.json',r)
print('REPORT_COMMIT',r['commit']);print(r['findings'])
PY
lab_python "$OUT" <<'PY'
from pathlib import Path
import json,sys
from lab import patch,save
out=Path(sys.argv[1]);r=json.loads((out/'fixed-md-report.json').read_text())
diff,edits=patch(out/'project',r)
(out/'candidate.patch').write_text(diff);save(out/'patch-plan.json',edits)
assert '+main.o: main.c unused.h config.h' in diff
assert (out/'project/Makefile').read_text().find('config.h')<0
print(diff);print(edits);print('PATCH_GENERATED_SOURCE_UNCHANGED')
PY
cp "$OUT/project/Makefile" "$OUT/source-before.Makefile"
printf 'SECTION_3_FINISHED\n'

printf 'MANUAL_SECTION=4\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import validate
out=Path(sys.argv[1]);p=out/'project';before=p.joinpath('Makefile').read_bytes()
r=validate(p,out/'candidate.patch',out/'reject-test',fail_test=True)
assert r['accepted'] is False and r['checks']['test'] is False
assert r['rollback'] is True and r['source_unchanged'] is True
assert p.joinpath('Makefile').read_bytes()==before==(out/'source-before.Makefile').read_bytes()
print('EXPECTED_TEST_REJECTION',r)
PY
printf 'SECTION_4_FINISHED\n'

printf 'MANUAL_SECTION=5\n'
cat "$OUT/reject-test/validation.json"
cat "$OUT/reject-test/build.log"
cat "$OUT/reject-test/incremental.log"
cmp "$OUT/source-before.Makefile" "$OUT/project/Makefile"
echo "SOURCE_CMP_EXIT=$?"
printf 'SECTION_5_FINISHED\n'

printf 'MANUAL_SECTION=6\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import validate
out=Path(sys.argv[1]);r=validate(out/'project',out/'candidate.patch',out/'accept')
assert r['accepted'] is True and all(r['checks'].values())
assert r['source_unchanged'] is False and r['rollback'] is False
assert 'main.o: main.c unused.h config.h' in (out/'project/Makefile').read_text()
print('ACCEPTED_ALL_CHECKS_PASS',r)
PY
printf 'SECTION_6_FINISHED\n'

printf 'MANUAL_SECTION=7\n'
cat "$OUT/accept/build.log"
cat "$OUT/accept/incremental.log"
cat "$OUT/accept/recheck.json"
git -C "$OUT/project" diff -- Makefile
cat "$OUT/project/config.h"
cat "$OUT/accept/sandbox/config.h"
printf 'SECTION_7_FINISHED\n'

printf 'MANUAL_SECTION=8\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import validate
out=Path(sys.argv[1]);p=out/'project';before=(p/'Makefile').read_bytes()
(out/'source-after-accept.Makefile').write_bytes(before)
(out/'broken.patch').write_text('invalid patch\n')
r=validate(p,out/'broken.patch',out/'reject-patch')
assert not r['accepted'] and r['rollback'] and r['source_unchanged']
assert (p/'Makefile').read_bytes()==before
print('EXPECTED_BAD_PATCH_REJECTION',r)
PY
printf 'SECTION_8_FINISHED\n'

printf 'MANUAL_SECTION=9\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import csv,json,sys
from lab import buildchecker,save
out=Path(sys.argv[1]);buildchecker(out/'project',out/'recheck-buildchecker')
report=json.loads((out/'recheck-buildchecker/findings.json').read_text())
assert not any(f['type']=='MISSING' for f in report['findings'])
rows=[]
for case,directory in [('test-rejection','reject-test'),('accepted','accept'),('patch-rejection','reject-patch')]:
 r=json.loads((out/directory/'validation.json').read_text())
 passed=r['accepted'] if case=='accepted' else r['rollback'] and r['source_unchanged'] and not r['accepted']
 assert passed;rows.append({'case':case,'passed':passed})
with (out/'results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['case','passed']);w.writeheader();w.writerows(rows)
save(out/'gate.json',{'track':'B','passed':True,'rows':len(rows)})
print('B_GATE_PASS',rows)
PY
printf 'SECTION_9_FINISHED\n'

printf 'MANUAL_SECTION=10\n'
cat "$OUT/results.csv"
cat "$OUT/gate.json"
git -C "$OUT/project" status --short
cmp "$OUT/source-after-accept.Makefile" "$OUT/project/Makefile"
echo "AFTER_REJECTION_CMP_EXIT=$?"
printf 'B E10：先错误测试拒绝，后正确候选接受，最后坏Patch拒绝；成功才写回，拒绝保留源字节。
' > "$OUT/结论.txt"
printf 'SECTION_10_FINISHED\n'

printf 'PERSONAL_E10_MANUAL_PASS OUT=%s\n' "$OUT"
