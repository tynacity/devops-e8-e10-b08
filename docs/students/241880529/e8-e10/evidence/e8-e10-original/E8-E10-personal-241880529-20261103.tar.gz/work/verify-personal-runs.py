import csv
import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]


def read_json(path):
    return json.loads(path.read_text())


e8 = root / (root / 'work/last-e8-B.path').read_text().strip()
e10 = root / (root / 'work/last-e10-B.path').read_text().strip()
for out in (e8, e10):
    assert read_json(out / 'session-exit.json')['exit_code'] == 0
    assert (out / 'student-source-commit.txt').read_text().strip() == '237aba981d55f4cbc426c40ae71187ffc4291959'
    assert (out / 'student-branch.txt').read_text().strip() == 'student/241880529/e8-e10'
    assert (out / 'environment-image-id.txt').read_text().strip() == 'sha256:7cb6eaab6f71a26c6236cb34b7a38d4f2ea4814faa81e2ef22033b65fd6061a7'
    subprocess.run(['sha256sum', '-c', str(out / 'source.sha256')], cwd=root, check=True)
    logs = list((out / 'steps').glob('*.log'))
    assert logs and all(p.read_text().rstrip().endswith('STEP_EXIT_CODE=0') for p in logs)
report = read_json(e8 / 'fixed-md-report.json')
assert {(f['type'], f['target'], f['dependency']) for f in report['findings']} == {
    ('MISSING', 'main.o', 'config.h'), ('REDUNDANT', 'main.o', 'unused.h')}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=e8 / 'project', text=True).strip() == report['commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=e8 / 'project').strip()
assert read_json(e8 / 'expected-failure.json') == {'error': 'STALE_REPORT'}
assert all(read_json(e8 / 'rd-only-result.json').values())
subprocess.run(['git', 'apply', '--check', str(e8 / 'candidate.patch')], cwd=e8 / 'project', check=True)
accepted = read_json(e10 / 'accept/validation.json')
assert accepted['accepted'] and all(accepted['checks'].values()) and accepted['error'] is None
for case in ('reject-test', 'reject-patch'):
    r = read_json(e10 / case / 'validation.json')
    assert not r['accepted'] and r['rollback'] and r['source_unchanged']
assert read_json(e10 / 'reject-test/validation.json')['checks']['test'] is False
assert (e10 / 'source-before.Makefile').read_bytes() == (e8 / 'project/Makefile').read_bytes()
assert (e10 / 'source-after-accept.Makefile').read_bytes() == (e10 / 'project/Makefile').read_bytes()
assert (e10 / 'project/config.h').read_text() == '#define VALUE 1\n'
assert (e10 / 'accept/sandbox/config.h').read_text() == '#define VALUE 2\n'
assert 'main.c' in (e10 / 'accept/incremental.log').read_text()
assert read_json(e10 / 'gate.json') == {'track': 'B', 'passed': True, 'rows': 3}
assert len(list(csv.DictReader((e10 / 'results.csv').open()))) == 3
dynamic = read_json(e10 / 'recheck-buildchecker/findings.json')
assert dynamic['status'] == 'SUCCEEDED' and not any(f['type'] == 'MISSING' for f in dynamic['findings'])
assert list((e10 / 'recheck-buildchecker/trace').iterdir())
extra = read_json(e10 / 'compile-failure/validation/validation.json')
assert extra['checks']['patch_applies'] and not extra['accepted'] and extra['rollback'] and 'COMMAND_FAILED' in extra['error']
log = (root / 'work/personal-baseline-unit-tests.log').read_text()
assert 'Ran 11 tests' in log and '\nOK\n' in log
result = {'passed': True, 'e8_out': str(e8.relative_to(root)), 'e10_out': str(e10.relative_to(root)),
          'unit_tests': 11, 'source_commit': report['commit'],
          'student_source_commit': '237aba981d55f4cbc426c40ae71187ffc4291959',
          'e8': 'all manual steps and RD-only pass',
          'e10': 'three-case gate, byte comparisons, dynamic recheck and compilation rejection pass'}
(root / 'work/personal-independent-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
