#!/usr/bin/env bash
set -euo pipefail
cd /root/241880529/github-e8-e10-20261103
mkdir -p work
exec > >(tee work/e8-personal-session.log) 2>&1
source work/course/classroom_helpers.sh
lab_ready
lab_new_run e8 B
trap 'code=$?; printf "{\"exit_code\":%s}\n" "$code" > "$OUT/session-exit.json"' EXIT
printf 'PERSONAL_OUT=%s\n' "$OUT"
sha256sum labs/e8e10/lab.py labs/e8e10/test_profile.py > "$OUT/source.sha256"
git branch --show-current > "$OUT/student-branch.txt"

printf 'MANUAL_SECTION=1\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import fixture
out=Path(sys.argv[1]); fixture(out/'project')
print('CREATED',out/'project')
PY
printf 'SECTION_1_FINISHED\n'

printf 'MANUAL_SECTION=2\n'
pwd
cat "$OUT/student-source-commit.txt"
cat "$OUT/project/Makefile"
cat "$OUT/project/main.c"
cat "$OUT/project/config.h"
cat "$OUT/project/helper.c"
git -C "$OUT/project" log -1 --oneline
printf 'SECTION_2_FINISHED\n'

printf 'MANUAL_SECTION=3\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import scan,save
out=Path(sys.argv[1]);r=scan(out/'project')
save(out/'fixed-md-report.json',r)
print('REPORT_COMMIT',r['commit']);print(r['findings'])
PY
printf 'SECTION_3_FINISHED\n'

printf 'MANUAL_SECTION=4\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import json,sys
from lab import run
out=Path(sys.argv[1]);r=json.loads((out/'fixed-md-report.json').read_text())
sha=run(['git','rev-parse','HEAD'],out/'project').strip()
assert r['commit']==sha
print('COMMIT_MATCH',sha)
print('MD',[f for f in r['findings'] if f['type']=='MISSING'])
PY
printf 'SECTION_4_FINISHED\n'

printf 'MANUAL_SECTION=5\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import json,sys
from lab import patch,save
out=Path(sys.argv[1]);r=json.loads((out/'fixed-md-report.json').read_text())
diff,edits=patch(out/'project',r)
(out/'candidate.patch').write_text(diff);save(out/'patch-plan.json',edits)
assert '+main.o: main.c unused.h config.h' in diff
assert (out/'project/Makefile').read_text().find('config.h')<0
print(diff);print(edits);print('PATCH_GENERATED_SOURCE_UNCHANGED')
PY
printf 'SECTION_5_FINISHED\n'

printf 'MANUAL_SECTION=6\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import run
out=Path(sys.argv[1]);print(run(['git','apply','--check',str((out/'candidate.patch').resolve())],out/'project'))
assert run(['git','status','--porcelain'],out/'project').strip()==''
print('APPLY_CHECK_PASS_SOURCE_CLEAN')
PY
printf 'SECTION_6_FINISHED\n'

printf 'MANUAL_SECTION=7\n'
lab_python "$OUT" <<'PY'
from pathlib import Path
import json,sys
from lab import patch,save
out=Path(sys.argv[1]);r=json.loads((out/'fixed-md-report.json').read_text());r['commit']='0'*40
before=(out/'project/Makefile').read_bytes()
try:
    patch(out/'project',r)
except ValueError as error:
    assert str(error)=='STALE_REPORT'
    save(out/'expected-failure.json',{'error':str(error)})
    print('EXPECTED_REJECTION',error)
else:
    raise AssertionError('旧报告未被拒绝')
assert before==(out/'project/Makefile').read_bytes()
print('SOURCE_BYTES_UNCHANGED')
PY
printf 'SECTION_7_FINISHED\n'

printf 'MANUAL_SECTION=8\n'
cat "$OUT/candidate.patch"
cat "$OUT/patch-plan.json"
cat "$OUT/expected-failure.json"
git -C "$OUT/project" status --short
printf 'B E8：候选仅增加config.h；保留RD和配方；旧报告拒绝；尚待E10质量验证。
' > "$OUT/结论.txt"
printf 'SECTION_8_FINISHED\n'

printf 'PERSONAL_E8_MANUAL_PASS OUT=%s\n' "$OUT"
