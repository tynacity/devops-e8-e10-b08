#!/usr/bin/env bash
set -euo pipefail
cd /root/241880529/github-e8-e10-20261103
exec > >(tee work/personal-extra-session.log) 2>&1
source work/course/classroom_helpers.sh
lab_ready
OUT=$(cat work/last-e8-B.path)
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import fixture,scan,patch,commit,save
out=Path(sys.argv[1]); p=out/'rd-only-project'; fixture(p)
f=p/'Makefile'; f.write_text(f.read_text().replace('main.c unused.h','main.c unused.h config.h'))
commit(p,'personal E8 RD-only input')
r=scan(p)
assert r['findings']==[{'type':'REDUNDANT','target':'main.o','dependency':'unused.h'}]
before=f.read_bytes(); diff,plan=patch(p,r)
assert diff=='' and plan==[] and f.read_bytes()==before
save(out/'rd-only-report.json',r)
save(out/'rd-only-result.json',{'passed':True,'patch_empty':diff=='','plan_empty':plan==[],'source_unchanged':f.read_bytes()==before})
print('PERSONAL_E8_RD_ONLY_PASS')
PY
OUT=$(cat work/last-e10-B.path)
lab_python "$OUT" <<'PY'
from pathlib import Path
import sys
from lab import fixture,scan,patch,validate,save
out=Path(sys.argv[1]); ext=out/'compile-failure'; p=ext/'project'; fixture(p)
r=scan(p); save(ext/'input-report.json',r)
diff,plan=patch(p,r); candidate=ext/'candidate.patch'; candidate.write_text(diff)
before=(p/'Makefile').read_bytes(); (p/'main.c').write_text('this is invalid C;\n')
result=validate(p,candidate,ext/'validation')
assert result['checks']['patch_applies'] is True
assert result['checks'].get('build',False) is False
assert 'COMMAND_FAILED' in result['error']
assert not result['accepted'] and result['rollback'] and result['source_unchanged']
assert (p/'Makefile').read_bytes()==before
save(ext/'independent-result.json',{'passed':True,'expected':'applicable patch rejected on compilation failure','source_unchanged':True})
print('PERSONAL_E10_COMPILE_FAILURE_REJECTION_PASS',result)
PY
printf 'PERSONAL_EXTRA_CASES_PASS\n'
