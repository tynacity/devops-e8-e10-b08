# E9 B组：隐式规则与实际LLM候选补充

## 范围和来源

本补充对应E8课件第11、14、17页及E9第19页的提高任务：隐式模式规则接入编译器`.d`文件与实际LLM候选。实现范围是固定的两个C源文件、项目内头文件、`%.o: %.c`模式规则；不声称实现任意Make语法、完整声明图/DIS或论文全项目规模。

显式规则仍由原`lab.py/patch()`处理。本补充在`implicit.py`中独立运行，避免用显式规则的正则匹配伪装为隐式规则支持。

## 流程

1. `prepare`创建新的故障项目和Git提交，执行初次构建，确认输出1。
2. 把`config.h`的VALUE改为2，执行增量Make，记录仍输出1的真实失败证据。
3. 恢复原始输入、清理构建产物，用`gcc -MM`确认实际头文件依赖，保存结构化MD报告。
4. 将完整Makefile、C源文件、头文件、报告commit及失败证据组合成`prompt.txt`，并保存输入/提示SHA-256。
5. 将提示原文提交给实际模型。保留原始JSON回复、调用标识、来源和时间，不把单元测试中的合成候选当作模型回复。
6. `receive`检查输入及提示身份、回复哈希和模型来源，从回复中的完整Makefile生成`candidate.patch`。源项目不写回。
7. `verify`在副本中检查/应用Patch，记录真实Make和程序命令、退出码、stdout/stderr。
8. 将候选、模型证据和验证记录交接E10。此处不执行生产源项目接受/回滚，不替代E10事务验证。

## 独立预期

| 场景 | 预期 |
| --- | --- |
| 未修复：修改config.h | 不重编，程序仍输出1，复现MD后果 |
| 修复后首次构建 | 输出1，生成包含config.h的main.d |
| 输入未变化再次Make | 对象和程序不重建，排除每次强制全量构建的假修复 |
| 修改config.h | main.o重编，helper.o不重编，输出2 |
| config.h新增include headers/extra.h | 输出3，main.d自动记录子目录头文件 |
| 只修改headers/extra.h | main.o重编，helper.o不重编，输出4 |
| clean | 删除生成的.d文件 |
| 全过程 | 原项目所有输入文件的哈希保持一致 |

## 复核命令

在服务器个人仓库根目录，以已有课程镜像运行：

```bash
IMAGE=sha256:7cb6eaab6f71a26c6236cb34b7a38d4f2ea4814faa81e2ef22033b65fd6061a7
OUT=work/e9-implicit-NEW-RUN
docker run --rm --network none --user "$(id -u):$(id -g)" -e HOME=/tmp \
  -v "$PWD:/course" -w /course "$IMAGE" \
  python3 labs/e8e10/implicit.py prepare --out "$OUT"
```

模型采集由外部调用完成。把实际返回的JSON与provenance保存为文件后：

```bash
docker run --rm --network none --user "$(id -u):$(id -g)" -e HOME=/tmp \
  -v "$PWD:/course" -w /course "$IMAGE" \
  python3 labs/e8e10/implicit.py receive --out "$OUT" \
  --response path/to/raw-response.json --provenance path/to/model-provenance.json

docker run --rm --network none --user "$(id -u):$(id -g)" -e HOME=/tmp \
  -v "$PWD:/course" -w /course "$IMAGE" \
  python3 labs/e8e10/implicit.py verify --out "$OUT"

docker run --rm --network none --user "$(id -u):$(id -g)" -e HOME=/tmp \
  -v "$PWD:/course" -w /course "$IMAGE" \
  python3 -m unittest discover -s labs/e8e10 -p test_profile.py -v
```

provenance至少包含`provider`、`model`、`prompt_sha256`、`response_sha256`；本次另记录模型请求标识与采集时间。运行镜像内不调用外部模型，只进行候选接收和验证。

## 提交材料

- `implicit.py`、`test_implicit.py`及`test_profile.py`中的测试入口。
- 故障项目、MD报告、原始构建与增量失败日志。
- `prompt.txt`、`input-manifest.json`、原始模型回复及provenance。
- `candidate.Makefile`、`candidate.patch`与候选哈希。
- `validation/result.json`、全部命令日志、保存的`main.d.saved`。
- 学生源码基线、当前工作区源码哈希、精确镜像ID、归档校验值。

## 贡献与AI记录

原教师参考实现不含本流程。本次使用Codex协助实现受限样例、上下文采集、原始回复接收、补丁生成、哈希绑定与独立验证。测试中使用的合成Makefile明确标记为`unit-test/synthetic`；正式候选必须来自实际保存的模型请求。

## 本次实际运行结果（2026-11-03）

- 服务器：`47.97.170.134`。
- 仓库：`/root/241880529/e9-member2-20261103`。
- 隐式规则证据目录：`work/e9-implicit-20261103/`。
- 调用方式：Codex实际子模型推理，继承当前会话模型；没有另外调用外部API。
- 模型请求标识：`01a19f5d-67a5-7eb0-bbe1-2c26189a909c`。
- 模型标签：当前会话`gpt-6.1-sol`，后端具体版本未由工具单独返回。
- 原始工具回复同时保存在`work/e9-implicit-model-transport.json`，供核对是否手工改写候选。
- 模型候选未手工修改；自动从完整Makefile生成统一diff。
- 提示SHA-256：`69855dd964bb9ab79e727ab199e05fdf044be31f4031e1375fbece84882c9b4d`。
- 候选Makefile SHA-256：`c0c275c6a8b7a2f55071675662a90559ce4fab397a01d6d93603fc39ba6d0119`。
- 精确运行镜像ID见上方IMAGE，所有构建和运行在`--network none`容器中执行。
- 故障基线：头文件改为2后，程序仍输出1。
- 审查后实际候选验证：`passed=true`，14个checks全部为true，程序输出序列`1/2/3/4`。
- 无变化不重建、无关helper目标不重编、`.d`自动跟踪新增间接头文件、clean删除`.d`和原输入保护均通过。

初次接收命令漏传`--user 0:0`，触发Git ownership检查，候选没有被处理；随后使用与prepare一致的用户执行成功。上方复核命令已明确用户身份。

这些结果证明本受限样例中的候选有效；E10成员仍需按其职责完成接受/拒绝和回滚矩阵。本次未提交、推送或运行GitLab CI。

## 审查补强与交接

- 通过GNU Make数据库的`MAKEFILE_LIST`确认Make实际加载`main.d`和`helper.d`。
- 新增头文件放入子目录，防止`$(wildcard *.h)`碰巧通过而`.d`完全未使用。
- 输入清单之外出现`GNUmakefile`等额外文件时拒绝，避免执行未记录的Make输入。
- 每次Make后核对副本中的源码、头文件和候选Makefile，拒绝配方偷偷改写源码。
- 原始模型回复按字节保存和哈希，支持CRLF回复。
- 9项隐式规则测试包含上述反例，以及构建成功但缺陷未修复、过期输入、回复哈希不匹配等情况。与原8项测试合计17项。

最终结果读取`work/e9-implicit-20261103/validation/result.json`。`validation-before-review/`是补强验证器前的历史结果，不作为最终判定。最终测试日志为`work/e9-implicit-final-reviewed-tests.log`；所有源文件的准确内容由`work/e9-final-source.sha256`绑定。源码基线提交不包含未提交改动，不能将基线SHA误写为个人实现提交。

交接E10时提供`candidate.patch`、原项目、MD报告、prompt、原始回复、provenance及上述最终验证目录。E10应继续做其负责的接受/拒绝、回滚和重检，不以这里的`passed`替代事务接受结论。
