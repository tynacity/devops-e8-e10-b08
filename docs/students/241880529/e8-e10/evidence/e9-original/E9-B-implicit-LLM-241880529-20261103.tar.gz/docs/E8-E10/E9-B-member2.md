# E9 B组：三种声明风格与重复依赖去重

本次对应成员2的E9职责。教师参考实现提供三种显式声明风格；个人改动为重复MD去重、独立回归测试和可重复的E9证据采集脚本。

后续已补做隐式模式规则与实际LLM候选，详见同目录`E9-B-implicit-LLM.md`。当前测试入口包含8项原E9测试和9项隐式规则测试，共17项；下方8项记录属于补做前的历史结果。

## 修复位置

| 风格 | 输入 | 补丁位置 |
| --- | --- | --- |
| direct | `main.o: main.c unused.h` | 在目标依赖行追加`config.h` |
| macro | `DEPS = main.c unused.h`，`main.o: $(DEPS)` | 在DEPS定义追加`config.h`，保留目标变量引用 |
| mixed | `HEADERS = unused.h`，`main.o: main.c $(HEADERS)` | 在目标行追加`config.h`，保留HEADERS及其引用 |

候选生成和应用检查保持三个原项目的Makefile字节不变。应用演示使用独立副本，保留`unused.h`及所有TAB开头的编译配方。副本用GCC依赖扫描确认不再有MD；E10的构建、程序输出、头文件变化和事务验收由成员3完成。

## 个人修改

- `labs/e8e10/lab.py`的`patch()`按`(target, dependency)`去重，保持首次出现顺序。
- `labs/e8e10/test_profile.py`增加一个独立测试，分别以direct/macro/mixed三个子用例传入三条相同MD。每种风格只允许一条plan、一处新增依赖，并实际应用Patch检查变量引用、配方和MD集合。
- `scripts/run_e9_b.py`采集三种风格的原项目、输入报告、Patch、plan、应用副本、源码哈希和结果JSON。输出目录必须是新的`work/`子目录。

此处“去重”针对同一份输入报告重复包含相同MD，不代表重复向已修项目应用旧报告的幂等操作。共享变量跨目标影响仍属于参考实现限制：纯变量声明修改变量定义，可能影响其他引用目标；本次不扩大语法或声明图支持范围。

## 验证方法

在Linux的仓库根目录，课程镜像已就绪后执行：

```bash
SID=$(git config --local user.name)
IMAGE="course-e8e10:$SID"
mkdir -p work
docker run --rm --network none --user "$(id -u):$(id -g)" \
  -e HOME=/tmp -v "$PWD:/course" -w /course "$IMAGE" \
  python3 -m unittest discover -s labs/e8e10 -p test_profile.py -v

OUT="work/e9-B-member2-$(date +%Y%m%d-%H%M%S)"
docker run --rm --network none --user "$(id -u):$(id -g)" \
  -e HOME=/tmp -e E9_EXECUTION_MODE=course-docker-network-none \
  -v "$PWD:/course" -w /course "$IMAGE" \
  python3 scripts/run_e9_b.py --out "$OUT"
git rev-parse HEAD > "$OUT/student-source-commit.txt"
docker image inspect "$IMAGE" --format '{{.Id}}' > "$OUT/environment-image-id.txt"
cat "$OUT/summary.json"
```

预期为8项测试`OK`，三条`STYLE_PASS`，最终`E9_B_PASS`，`summary.json`中`passed=true`。正式运行还需保存命令输出日志及脚本退出码。

## 当前验证记录

2026-11-03在本机WSL Ubuntu中执行真实Git/GCC验证。新增测试在修复前的direct/macro/mixed三个子用例全部失败，修复后连同原7项测试共8项通过。

同日已在`47.97.170.134`课程Docker镜像内完成验证：8项测试通过，三个风格均输出`STYLE_PASS`，采集脚本输出`E9_B_PASS`，两个命令退出码均为0。

- 独立服务器仓库：`/root/241880529/e9-member2-20261103`
- 服务器分支：`student/241880529/e9`
- 基线提交：`47256f6395c95055cda3ee1046b547e0b55dd501`，来源为`origin/E8-E10-B`。
- 此次代码在基线上含未提交E9改动，精确内容以证据中的`execution-context.json/source_sha256`为准。`student-source-commit.txt`记录基线，不能将它声称为包含个人改动的提交。
- 使用镜像ID：`sha256:7cb6eaab6f71a26c6236cb34b7a38d4f2ea4814faa81e2ef22033b65fd6061a7`。
- 容器运行参数：`--network none`，镜像直接使用上述精确ID。
- 最终运行证据：`work/e9-B-member2-20261103-02/`（统一LF换行后重新验证）。
- 单元测试日志：`work/e9-tests-docker-02.log`。
- 运行日志：`work/e9-run-docker-02.log`。
- `summary.json`中三个风格的`patch_applies/source_unchanged/recipe_unchanged/redundant_preserved/copy_has_no_missing`全部为true。

E9技术实现和服务器验证完成。个人提交、推送/MR及GitLab CI由后续提交流程记录；GitLab不会执行仓库内的GitHub Actions文件，本次没有产生GitLab流水线结果。

## AI使用与贡献边界

使用Codex（GPT-6.1，2026-11-03）阅读教师手册、比较仓库基线、编写去重修改、回归测试和采集脚本，执行本地Linux及服务器课程Docker验证。三种声明风格机制来自教师参考代码；本次个人新增内容为上述去重逻辑、独立测试、采集脚本和本记录。
