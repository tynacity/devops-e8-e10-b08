import json, tempfile, unittest
from pathlib import Path
from lab import fixture,scan,patch,commit

class ProfileTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.p=Path(self.tmp.name)/'sample';fixture(self.p)

    def test_independent_known_edges(self):
        r=scan(self.p)
        self.assertEqual(r['actual']['main.o'],['config.h','main.c'])
        self.assertEqual({(f['type'],f['dependency']) for f in r['findings']},{('MISSING','config.h'),('REDUNDANT','unused.h')})

    def test_unchanged_reuses_both_targets(self):
        r=scan(self.p,scan(self.p));self.assertEqual(r['reused'],['main.o','helper.o']);self.assertEqual(r['refreshed'],[])

    def test_include_added_invalidates_cache(self):
        old=scan(self.p)
        (self.p/'main.c').write_text('#include "extra.h"\n'+(self.p/'main.c').read_text());commit(self.p,'new include')
        r=scan(self.p,old)
        self.assertIn(['MISSING','main.o','extra.h'],r['added']);self.assertEqual(len(r['refreshed']),2)

    def test_patch_preserves_redundant_dependency(self):
        r=scan(self.p);diff,plan=patch(self.p,r)
        self.assertIn('+main.o: main.c unused.h config.h',diff)
        self.assertNotIn('-\tgcc',diff)
        self.assertNotIn('config.h',(self.p/'Makefile').read_text())

    def test_old_report_rejected(self):
        r=scan(self.p);r['commit']='0'*40
        with self.assertRaisesRegex(ValueError,'STALE_REPORT'):patch(self.p,r)

    def test_unsafe_dependency_rejected(self):
        r=scan(self.p);r['findings']=[{'type':'MISSING','target':'main.o','dependency':'../outside.h'}]
        with self.assertRaisesRegex(ValueError,'UNSAFE_PATH'):patch(self.p,r)

    def test_unsupported_configuration_rejected(self):
        (self.p/'Makefile').write_text((self.p/'Makefile').read_text().replace('-O0','-include unknown.h'))
        with self.assertRaisesRegex(ValueError,'UNSUPPORTED_FLAGS'):scan(self.p)

class E9StudentTests(unittest.TestCase):
    def test_duplicate_missing_findings_produce_one_edit_per_style(self):
        from lab import run
        for style in ('direct', 'macro', 'mixed'):
            with self.subTest(style=style), tempfile.TemporaryDirectory() as directory:
                project = Path(directory) / 'project'
                fixture(project, style)
                report = scan(project)
                missing = next(f for f in report['findings'] if f['type'] == 'MISSING')
                report['findings'].extend([dict(missing), dict(missing)])
                before = (project / 'Makefile').read_bytes()
                diff, plan = patch(project, report)
                self.assertEqual(plan, [{'target': 'main.o', 'dependency': 'config.h', 'style': style}])
                self.assertEqual((project / 'Makefile').read_bytes(), before)
                candidate = Path(directory) / 'candidate.patch'
                candidate.write_text(diff)
                run(['git', 'apply', '--check', str(candidate)], project)
                run(['git', 'apply', str(candidate)], project)
                after = (project / 'Makefile').read_bytes()
                self.assertEqual(after.count(b'config.h'), 1)
                self.assertEqual(
                    [line for line in before.splitlines() if line.startswith(b'\t')],
                    [line for line in after.splitlines() if line.startswith(b'\t')])
                expected = {
                    'direct': 'main.o: main.c unused.h config.h',
                    'macro': 'DEPS = main.c unused.h config.h',
                    'mixed': 'main.o: main.c $(HEADERS) config.h',
                }[style]
                self.assertIn(expected, after.decode())
                if style == 'macro':
                    self.assertIn('main.o: $(DEPS)', after.decode())
                self.assertFalse(any(f['type'] == 'MISSING' for f in scan(project)['findings']))

from test_implicit import ImplicitRepairTests

if __name__=='__main__':unittest.main()
