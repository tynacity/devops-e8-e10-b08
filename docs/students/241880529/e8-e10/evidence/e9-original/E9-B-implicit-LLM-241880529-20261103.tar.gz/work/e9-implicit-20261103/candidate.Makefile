CC = gcc
CFLAGS = -O0
OBJS = main.o helper.o

app: $(OBJS)
	$(CC) $(OBJS) -o $@

%.o: %.c
	$(CC) $(CFLAGS) -MMD -MP -c $< -o $@

.PHONY: clean
clean:
	rm -f $(OBJS) $(OBJS:.o=.d) app

-include $(OBJS:.o=.d)
