import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
out = root / 'work/member2-e13-component'
sys.path[:0] = [str(root / 'labs/e13e14'), str(root / 'labs/e11e12')]
from mdfixer import repair
from lab import scan

records = []
for name, argv in (
    ('component-tests', ['python3', '-m', 'unittest', 'discover', '-s', 'labs/e13e14/tests', '-p', 'test_member2_mdfixer.py', '-v']),
    ('e11e12-tests', ['python3', '-m', 'unittest', 'discover', '-s', 'labs/e11e12', '-v']),
    ('e8e10-tests', ['python3', '-m', 'unittest', 'discover', '-s', 'labs/e8e10', '-p', 'test_profile.py', '-v']),
):
    with (out / (name + '.log')).open('wb') as log:
        proc = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT)
    records.append({'command': argv, 'exit_code': proc.returncode, 'log': name + '.log'})
    print(name, proc.returncode, flush=True)
    assert proc.returncode == 0

repo = root / 'data/e13-upstream-student/H2-inih/repo'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert head == '3aadb81763c79651e4dfa99b725ba921ee2b8a39'
report = out / 'h2-local-fixed-md.json'
report.write_text(json.dumps({'schema_version': 'e11e12-1', 'kind': 'fixed-md', 'status': 'SUCCEEDED',
                            'commit': head, 'data': scan(repo)}, indent=2) + '\n')
for name, profile, source, target, input_path in (
    ('h2', 'explicit', repo, head, report),
    ('tinyexpr', 'tinyexpr', root / 'data/real-project', 'db16775c83f90ead79255cc124d2a5f62f58a3b3',
     root / 'fixtures/e11e12/tinyexpr-md/accept.json'),
):
    request = {'profile': profile, 'repo': str(source), 'target': target,
               'report': str(input_path), 'report_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest()}
    (out / (name + '-request.json')).write_text(json.dumps(request, indent=2) + '\n')
    result = repair(request, out / (name + '-run'))
    assert result['status'] == 'SUCCEEDED', result
    print(name, result['status'], flush=True)

source_files = ['labs/e13e14/mdfixer.py', 'labs/e13e14/tests/test_member2_mdfixer.py']
metadata = {'baseline': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'scope': '5.1 component verification only; local fixed reports, Linux process runtime',
            'commands': records, 'source_sha256': {
                n: hashlib.sha256((root / n).read_bytes()).hexdigest() for n in source_files},
            'python': sys.version, 'platform': os.uname()._asdict() if hasattr(os.uname(), '_asdict') else list(os.uname())}
(out / 'verification.json').write_text(json.dumps(metadata, indent=2) + '\n')
