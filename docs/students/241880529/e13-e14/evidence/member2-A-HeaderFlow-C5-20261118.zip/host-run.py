import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

base = Path('/root/241880529/headerflow-c5-20261118')
repo = base / 'repo'
if not repo.exists():
    subprocess.run(['git','clone','--branch','student/241880529/e13-e14',
                    str(base/'headerflow-tool-20261118.bundle'),str(repo)],check=True)
archive=base/'headerflow-input-20261118.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='b5f87cfbc7472549bc461d6fc5f79953ef524d5f0470aa16e82d714772fba4a8'
with ZipFile(archive) as z:
    z.extractall(repo/'data/headerflow')
receipt=json.loads((repo/'data/headerflow/receipt.json').read_bytes())
image=receipt['DRAFT_application_image_id']
assert image=='sha256:596aa607c88a4c98d17ae5e808b08540a9d23d820a24c62c9969576655b18163'
project=repo/'data/headerflow/project/repo'
# The input ZIP stores Git's empty refs directories as directory entries.
# Restore these directories when reconstructing the file-only transfer ZIP.
(project/'.git/refs/heads').mkdir(parents=True,exist_ok=True)
(project/'.git/refs/tags').mkdir(exist_ok=True)
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=project,text=True).strip())==project
target=receipt['project_target_sha']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip()
assert head==target=='961f40cb8fbb71de304b782ff754522d59d51305'
subprocess.run(['git','merge-base','--is-ancestor',receipt['project_base_sha'],target],cwd=project,check=True)
out=repo/'work/headerflow-c5'
out.mkdir(parents=True)
inspect=json.loads(subprocess.check_output(['docker','image','inspect',image]))
assert inspect[0]['Architecture']=='amd64'
(out/'image-inspect.json').write_text(json.dumps(inspect,indent=2)+'\n')
common=['docker','run','--rm','--network','none','--cap-add','SYS_PTRACE','--user','0:0',
        '-e','HOME=/tmp','-v',str(repo)+':/course','-w','/course','--entrypoint','python3',image]
records=[]
def run(name,args):
    argv=common+args
    with (out/(name+'.stdout.log')).open('wb') as stdout,(out/(name+'.stderr.log')).open('wb') as stderr:
        p=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=300)
    records.append({'name':name,'command':argv,'exit_code':p.returncode})
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    assert p.returncode==0,(name,p.returncode)
    print(name,'PASS',flush=True)
probe="import hashlib,json;from pathlib import Path;p=Path('/work');print(json.dumps({n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ['main.c','helper.c','Makefile','config.h','extra.h','unused.h']}))"
run('image-input-probe',['-c',probe])
copied=json.loads((out/'image-input-probe.stdout.log').read_bytes())
for name,digest in copied.items():
    assert hashlib.sha256((project/name).read_bytes()).hexdigest()==digest,name
run('member2-tests',['-m','unittest','discover','-s','labs/e13e14/tests','-p','test_member2*.py','-v'])
run('existing-contracts',['-m','unittest','discover','-s','labs/e11e12','-v'])
run('C5',['labs/e13e14/run_member2_c5.py','--repo','/course/data/headerflow/project/repo',
          '--target',target,'--report','/course/data/headerflow/a-report/incremental-check.json',
          '--producer-manifest','/course/data/headerflow/a-report/result.json',
          '--report-sha256',receipt['source_report_sha256'],'--out','/course/work/headerflow-c5/run'])
result=json.loads((out/'run/result.json').read_bytes())
assert result['original_source_unchanged']
assert result['input_report']['job_id']==receipt['source_job_id']
assert result['input_report']['sha256']==receipt['source_report_sha256']
for case in ('missing-config','compile-error'):
    p=out/'run'/case
    assert (p/'target-before.json').read_bytes()==(p/'target-after.json').read_bytes()
    assert json.loads((p/'validation/validation.json').read_bytes())['rollback']
assert (out/'run/source-before.json').read_bytes()==(out/'run/source-after.json').read_bytes()
assert 'A_HEADERFLOW_BEHAVIOR=PASS' in (out/'run/positive/project-behavior.log').read_text()
metadata={'tool_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
          'image_id':image,'source_project_base':receipt['project_base_sha'],'source_project_target':target,
          'A_job_id':receipt['source_job_id'],'A_trace_id':receipt['source_trace_id'],
          'A_report_sha256':receipt['source_report_sha256'],'image_inputs_match_original':copied,
          'member2_tests':15,'existing_contracts':24,'result':result}
metadata['source_sha256']={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in
                         ('labs/e13e14/run_member2_c5.py','labs/e13e14/tests/test_member2_c5.py')}
(out/'verification.json').write_text(json.dumps(metadata,indent=2)+'\n')
contents={p.relative_to(out).as_posix():p.read_bytes() for p in out.rglob('*') if p.is_file()}
contents['inputs.zip']=archive.read_bytes()
contents['host-run.py']=Path(__file__).read_bytes()
contents['SHA256SUMS.txt']=''.join(f'{hashlib.sha256(b).hexdigest()}  {n}\n' for n,b in sorted(contents.items())).encode()
dest=base/'member2-A-HeaderFlow-C5-20261118.zip'
with ZipFile(dest,'x',ZIP_DEFLATED) as z:
    for n,b in contents.items():z.writestr(n,b)
print(json.dumps(metadata,indent=2))
print('ARCHIVE',dest,hashlib.sha256(dest.read_bytes()).hexdigest(),len(contents))
