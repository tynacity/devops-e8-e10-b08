import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=['original', 'revised', 'c5', 'consume'])
phase = parser.parse_args().phase
base = Path('/root/241880529/e13-e14-member2-20261117')
repo = base / 'repo'
if not repo.exists():
    subprocess.run(['git', 'clone', '--branch', 'student/241880529/e13-e14',
                    str(base / 'member2-e13-source.bundle'), str(repo)], check=True)
    subprocess.run(['git', 'config', '--local', 'user.name', '241880529'], cwd=repo, check=True)
    archive = base / 'e13-upstream-student.zip'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'd9818c5f34d6ff5b6016222dabd7f56daca09ceaa5f525be214e146e3d485435'
    with zipfile.ZipFile(archive) as z:
        z.extractall(repo / 'data')
project = repo / 'data/e13-upstream-student/H2-inih'
target = '3aadb81763c79651e4dfa99b725ba921ee2b8a39'
parent = 'aafc740a2cac05a74541abede93b7d59ed23b87f'
subprocess.run(['git', '-C', str(project / 'repo'), 'merge-base', '--is-ancestor', parent, target], check=True)
assert subprocess.check_output(['git', '-C', str(project / 'repo'), 'rev-parse', 'HEAD'], text=True).strip() == target
work = repo / 'work'
work.mkdir(exist_ok=True)
folder = work / ('member2-' + phase + '-cloud')
assert not folder.exists(), folder
def source_state():
    source = project / 'repo'
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=source, text=True).strip()
    names = git('ls-files', '-z').split('\0')
    return {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain'),
            'files': {n: hashlib.sha256((source / n).read_bytes()).hexdigest() for n in names if n}}
before = source_state()
(work / (folder.name + '.source-before.json')).write_text(json.dumps(before, indent=2) + '\n')
service = 'sha256:1fa773b9ed7fdf35281eda86ec53ebf61048f271a70a43f9ccfd0e2d7a759829'
if phase in ('c5', 'consume'):
    image = json.loads((work / 'member2-revised-cloud/result.json').read_bytes())['execution_image_id']
    argv = ['docker', 'run', '--rm', '--network', 'none', '--cap-add', 'SYS_PTRACE',
            '--user', '0:0', '-e', 'HOME=/tmp', '-v', str(repo) + ':/course', '-w', '/course',
            '--entrypoint', 'python3', image, 'labs/e13e14/run_member2_c5.py',
            '--repo', '/course/data/e13-upstream-student/H2-inih/repo', '--target', target,
            '--out', '/course/work/' + folder.name]
    if phase == 'consume':
        report = work / 'member2-revised-cloud/incremental-check.json'
        request = {'profile': 'explicit', 'repo': '/course/data/e13-upstream-student/H2-inih/repo',
                   'target': target, 'report': '/course/work/member2-revised-cloud/incremental-check.json',
                   'producer_manifest': '/course/work/member2-revised-cloud/result.json',
                   'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest()}
        request_path = work / 'member2-consume-request.json'
        request_path.write_text(json.dumps(request, indent=2) + '\n')
        argv = argv[:argv.index('labs/e13e14/run_member2_c5.py')] + [
            'labs/e13e14/mdfixer.py', '--request', '/course/work/member2-consume-request.json',
            '--out', '/course/work/' + folder.name]
else:
    candidate = project / 'candidate.Dockerfile'
    if phase == 'revised':
        candidate = project / 'candidate.member2-tools.Dockerfile'
        text = (project / 'candidate.Dockerfile').read_text()
        assert 'build-essential &&' in text
        candidate.write_text(text.replace('build-essential &&', 'build-essential git strace &&'))
    request = {'mode': 'e12', 'repo': '/course/data/e13-upstream-student/H2-inih/repo',
               'base': parent, 'target': target, 'candidate': '/course/' + candidate.relative_to(repo).as_posix(),
               'expected_output': '1', 'build_timeout': 600}
    request_path = project / ('request-member2-' + phase + '.json')
    request_path.write_text(json.dumps(request, indent=2) + '\n')
    argv = ['docker', 'run', '--rm', '--user', '0:0', '--cap-add', 'SYS_PTRACE',
            '-v', str(repo) + ':/course', '-v', '/var/run/docker.sock:/var/run/docker.sock',
            '-w', '/course', '-e', 'HOME=/tmp', '-e', 'E11_HOST_ROOT=' + str(repo),
            '-e', 'PYTHONPATH=/course/labs/e11e12:/course/labs/e8e10:/course/labs/e11e12/vendor:/app',
            service, 'python3', 'labs/e11e12/pipeline.py', '--request',
            '/course/' + request_path.relative_to(repo).as_posix(), '--out', '/course/work/' + folder.name]
with (work / (folder.name + '.stdout.log')).open('wb') as stdout, (work / (folder.name + '.stderr.log')).open('wb') as stderr:
    proc = subprocess.run(argv, cwd=repo, stdout=stdout, stderr=stderr, timeout=1200)
(work / (folder.name + '.command.json')).write_text(json.dumps({'argv': argv, 'exit_code': proc.returncode}, indent=2) + '\n')
after = source_state()
(work / (folder.name + '.source-after.json')).write_text(json.dumps(after, indent=2) + '\n')
assert before == after, 'Original H2 source changed'
print('phase', phase, 'exit', proc.returncode, flush=True)
if (folder / 'result.json').exists():
    result = json.loads((folder / 'result.json').read_bytes())
    print(json.dumps({k: result[k] for k in ('status', 'job_id', 'trace_id', 'execution_image_id', 'error') if k in result}, indent=2), flush=True)
else:
    print((work / (folder.name + '.stderr.log')).read_text()[-3000:])
