import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZipFile, ZIP_DEFLATED

base = Path('/root/241880529/e13-e14-member2-20261117')
repo = base / 'repo'
work = repo / 'work'
def load(path):
    return json.loads(path.read_bytes())
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()

failed = load(work / 'member2-original-cloud/result.json')
passed_dir = work / 'member2-revised-cloud'
passed = load(passed_dir / 'result.json')
assert failed['status'] == 'FAILED' and failed['error']['code'] == 'FULL_CHECK_FAILED'
assert 'strace' in failed['error']['message']
assert passed['status'] == 'SUCCEEDED'
assert [s['name'] for s in passed['stages']] == ['draft','full-check','incremental-check','repair','recheck']
for artifact in passed['artifacts']:
    name = artifact['uri'].split('/', 3)[-1]
    assert artifact['uri'].startswith('artifact://' + passed['job_id'] + '/')
    assert sha((passed_dir / name).read_bytes()) == artifact['sha256'], name
for name in ['draft', 'full-check', 'incremental-check', 'repair', 'recheck']:
    envelope = load(passed_dir / (name + '.json'))
    assert envelope['job_id'] == passed['job_id'] and envelope['trace_id'] == passed['trace_id']
    expected = passed['base_commit'] if name == 'full-check' else passed['target_commit']
    assert envelope['commit'] == expected
repair = load(passed_dir / 'repair.json')
assert repair['data']['input_report']['sha256'] == sha((passed_dir / 'incremental-check.json').read_bytes())
assert all(load(passed_dir / 'validation/validation.json')['checks'].values())
assert not any(f['type'] == 'MISSING' for f in load(passed_dir / 'final-full/findings.json')['findings'])
for folder in passed_dir.joinpath('runtime').iterdir():
    record = load(folder / 'command.json')
    assert record['image_id'] == passed['execution_image_id'] and record['exit_code'] == 0
    assert passed['execution_image_id'] in record['command']
for phase in ('revised', 'c5', 'consume'):
    prefix = work / ('member2-' + phase + '-cloud')
    assert load(prefix.with_suffix('.source-before.json')) == load(prefix.with_suffix('.source-after.json'))
c5 = work / 'member2-c5-cloud'
assert load(c5 / 'result.json')['original_source_unchanged']
for case in ('missing-config', 'compile-error'):
    assert load(c5 / case / 'target-before.json') == load(c5 / case / 'target-after.json')
    assert load(c5 / case / 'validation/validation.json')['rollback']
assert not any(f['type'] == 'MISSING' for f in load(c5 / 'positive/recheck.json')['findings'])
consumer = work / 'member2-consume-cloud'
assert load(consumer / 'result.json')['status'] == 'SUCCEEDED'
assert load(consumer / 'result.json')['original_source_unchanged']
assert (consumer / 'consumed-report.json').read_bytes() == (passed_dir / 'incremental-check.json').read_bytes()
assert load(consumer / 'result.json')['input']['job_id'] == passed['job_id']
assert not any(f['type'] == 'MISSING' for f in load(consumer / 'recheck.json')['findings'])
candidate = repo / 'data/e13-upstream-student/H2-inih/candidate.member2-tools.Dockerfile'
assert sha(candidate.read_bytes()) == 'f1e25df27f06b421ba29f62e346c0493d410c72e4410bca2b85e045398c45a7b'
metadata = {'tool_commit': git('rev-parse', 'HEAD'), 'tool_status': git('status', '--porcelain'),
            'host': subprocess.check_output(['uname', '-smr'], text=True).strip(),
            'candidate_sha256': sha(candidate.read_bytes()), 'failed_job': failed['job_id'],
            'job_id': passed['job_id'], 'trace_id': passed['trace_id'],
            'execution_image_id': passed['execution_image_id'], 'artifacts_verified': len(passed['artifacts']),
            'runtime_operations_verified': len(list((passed_dir / 'runtime').iterdir())),
            'source_files': {}, 'project': {'base': passed['base_commit'], 'target': passed['target_commit']}}
for name in ['labs/e11e12/pipeline.py','labs/e11e12/runtime_worker.py','labs/e11e12/draft_runtime.py',
             'labs/e8e10/lab.py','labs/e13e14/mdfixer.py','labs/e13e14/run_member2_c5.py',
             'labs/e11e12/vendor/draft/autobuild.py']:
    metadata['source_files'][name] = sha((repo / name).read_bytes())
metadata['service_image'] = json.loads(subprocess.check_output(['docker','image','inspect',
    'sha256:1fa773b9ed7fdf35281eda86ec53ebf61048f271a70a43f9ccfd0e2d7a759829']))[0]['Id']
metadata['component_consumed_current_report'] = True
metadata['input_report_sha256'] = sha((consumer / 'consumed-report.json').read_bytes())
metadata['services_after'] = subprocess.check_output(['docker', 'ps', '--format', '{{.Names}} {{.Image}} {{.Ports}}'], text=True).splitlines()
assert not metadata['tool_status']
bundle = base / 'H2-history.bundle'
subprocess.run(['git','-C',str(repo / 'data/e13-upstream-student/H2-inih/repo'),
                'bundle','create',str(bundle),'--all'], check=True)
contents = {'verification.json': (json.dumps(metadata, indent=2) + '\n').encode(),
            'host-run.py': (base / 'run.py').read_bytes(), 'cloud-audit.py': Path(__file__).read_bytes(),
            'input/H2-history.bundle': bundle.read_bytes()}
for p in work.glob('member2-*'):
    if p.is_dir():
        for f in p.rglob('*'):
            if f.is_file():
                contents['work/' + f.relative_to(work).as_posix()] = f.read_bytes()
    elif p.is_file():
        contents['work/' + p.name] = p.read_bytes()
project = repo / 'data/e13-upstream-student/H2-inih'
for p in project.glob('*'):
    if p.is_file():
        contents['input/' + p.name] = p.read_bytes()
contents['SHA256SUMS.txt'] = ''.join(f'{sha(raw)}  {name}\n' for name, raw in sorted(contents.items())).encode()
archive = base / 'member2-H2-C5-cloud-final-20261117.zip'
with ZipFile(archive,'x',ZIP_DEFLATED) as z:
    for name, raw in contents.items():
        z.writestr(name, raw)
print(json.dumps(metadata, indent=2))
print('ARCHIVE', archive, sha(archive.read_bytes()), 'FILES', len(contents))
