#!/bin/bash
cd /root/241880492/e11-e12-pr10-20261113-8aa1dd2 || exit 1
docker run --rm --name e12-member4-pr10-8aa1dd2 --network bridge --group-add "$(stat -c %g /var/run/docker.sock)" -v /var/run/docker.sock:/var/run/docker.sock --cap-add SYS_PTRACE --user "$(id -u):$(id -g)" -e HOME=/tmp -e E11_HOST_ROOT="$PWD" -e PYTHONDONTWRITEBYTECODE=1 -e PYTHONPATH=/course/labs/e11e12:/course/labs/e8e10:/course/labs/e11e12/vendor:/app -v "$PWD:/course" -w /course sha256:1fa773b9ed7fdf35281eda86ec53ebf61048f271a70a43f9ccfd0e2d7a759829 python3 labs/e11e12/pipeline.py --request fixtures/e11e12/tinyexpr-request.json --out work/member4-tinyexpr-e12 > work/member4-tinyexpr-e12.log 2>&1
rc=$?
printf '%s\n' "$rc" > work/member4-tinyexpr-e12.exit
exit "$rc"
