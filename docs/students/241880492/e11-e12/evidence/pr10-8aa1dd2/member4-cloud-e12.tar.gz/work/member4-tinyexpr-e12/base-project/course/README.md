# TinyExpr E11 E12 integration input

This branch preserves TinyExpr's upstream history and Zlib license. The course
additions are a deliberately incomplete container environment and an independent
example-output check. They do not change the upstream library or repair its
Makefile dependencies.

The initial course commit is based on upstream
`c9049eb7495d4aad71e12af0be190407125e86ea`. The next course revision incorporates
upstream `ba2e32bbcc2d1e644a7e132d24c2f542821cabe0` through a merge, retaining the
original authors and commits. Exact course base/target SHAs belong in the
experiment repository's dataset manifest after the revisions are created.

## Build and behavior

```sh
make clean
make example
python3 course/verify_example.py
make smoke
```

Dependency analysis is scoped to `make example`: `example.o`, `tinyexpr.o`, and
the executable `example`. `make smoke` is an additional behavior regression;
it is not included in the dependency-repair acceptance scope. Both objects
include `tinyexpr.h`, which the original suffix rule does not declare.

`Dockerfile.broken` intentionally omits Make. Member 1 supplies the repair
candidate, its provenance, pinned base digest, actual image, and two build logs.
The candidate must preserve the COPY, build, and CMD instructions and add the
required installation steps under the existing DRAFT contract. A local C build
does not establish Docker success or downstream environment reuse.

The DevOps runner still needs project mapping, suffix-rule, compiler flag,
behavior validation, and image-handoff adaptation. This branch is input data,
not a completed E11/E12 result. Source maintenance here does not by itself
establish instructor approval of the fork as the course's real-project choice.
