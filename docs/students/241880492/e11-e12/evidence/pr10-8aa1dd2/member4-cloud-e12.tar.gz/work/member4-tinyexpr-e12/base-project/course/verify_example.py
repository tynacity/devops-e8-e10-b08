"""Check the upstream example against an independent mathematical oracle.

Run after `make example`. This does not test dependency repair or Docker.
"""
import math
from pathlib import Path
import subprocess


def main():
    project = Path(__file__).resolve().parents[1]
    result = subprocess.run([str(project / 'example')], cwd=project,
                            text=True, capture_output=True, check=True, timeout=10)
    expected = ('The expression:\n\tsqrt(5^2+7^2+11^2+(8-2)^2)\n'
                f'evaluates to:\n\t{math.sqrt(231):.6f}\n')
    if result.stdout != expected:
        raise SystemExit(f'Unexpected example output: {result.stdout!r}; expected {expected!r}')
    print('PASS: example matches sqrt(231) rounded to six decimal places')


if __name__ == '__main__':
    main()
