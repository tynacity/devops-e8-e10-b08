# 2026-11-19｜G2 HeaderFlow 输入送核

拟复测 B 分支 `student/241880492/e13-e14-paired-acceptance`，提交 `ac923c516129d863346710ce029d37b12ea8336c`。已从远端分支恢复该提交，单独检出，工作区干净。使用公共 API `POST /v1/jobs`，`mode=e13-b`。本说明仅确认输入，C1–C3 尚未上机执行。

| 冻结项 | 值 |
| --- | --- |
| A 冻结编号 | `G2-A-20261118-0408405-v1` |
| A 工具源码 | `04084055221c9f59683d648b3766f86ed07bdd73` |
| HeaderFlow base | `88af5173a249ee4f30f3d7da51b20169db47d234` |
| HeaderFlow target | `961f40cb8fbb71de304b782ff754522d59d51305` |
| 候选 `candidate.Dockerfile` SHA-256 | `3836baf65c06a241b58505606714f4d443067ae894390471335ff212db1437dd` |
| A 生产 job / trace | `job-10302c35430f449993b0caa0d7050bb8` / `trace-ff64eab93d4b4a35b606cc9009db7340` |
| `incremental-check.json` SHA-256 | `45a1067267c489716c441b3edadf1be0132ff74378b81902c7c957beadb4e838` |
| `result.json` SHA-256 | `6ccab6bc665dd4838f5dc0d4cb55cf29e371b1b42696b20081eae8ba1eddf029` |

**沿用项：** 项目 base、target 和候选文件 SHA 与首轮联调一致；预期输出仍为 `1`。**变化项：** A 工具版本、生产任务、报告与生产清单均为 G2 新版本。附件中的两份 JSON 是 A 原始字节，不重新格式化；保持旧 C1 回执仅用于历史追溯。

当前测试约定：C2 使用真实 base 作为错误目标，期望 `STALE_REPORT`；C3 只修改一个 JSON 缩进字节、长度不变、声明 SHA 和生产者清单保持原样，期望 `ARTIFACT_HASH_MISMATCH`；两项均须在 DRAFT 前被拒绝。C1 使用未经修改的新报告，核对身份、实际镜像、补丁接受、动态重检及原项目保护。
