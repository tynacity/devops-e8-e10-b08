# A-HeaderFlow

A 组 E13 项目，由组长结合 Codex 从课程 E11/E12 双 C/Make 样例演进。
原始课程基线：8f56e1bbf120a5649820750168d935699bf44ec3。
只在本轮新副本修改，不冒称独立外部项目或某组员的个人实现。

C0：保留双 C 编译接口，新增项目说明、行为回归与测试目标，重写 helper 函数体。
C1：main 和 helper 都引用 extra.h，helper 的返回值实际依赖 EXTRA；
Make 声明保持原缺失依赖，用于交叉检验全量/增量报告及修复。
正常输出 1；config.h 的 VALUE 改为2且正确重建后输出2。

构建：make clean && make app。行为回归：python3 tests/verify_behavior.py。
运行：./app。语言：C；显式 Make 规则；CFLAGS=-O0。
限制：课程教学规模；不代表完整论文实现，未做大项目性能推断。
来源许可：课程提供样例未声明独立开源许可；仅按课程授权在 A/B
组内交换、测试和提交，不添加或冒认上游开源许可证。
