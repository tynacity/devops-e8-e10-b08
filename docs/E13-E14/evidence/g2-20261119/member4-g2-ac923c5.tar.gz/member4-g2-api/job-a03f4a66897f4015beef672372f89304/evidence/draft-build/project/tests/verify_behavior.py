from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
subprocess.run(['make','clean'],cwd=root,check=True)
subprocess.run(['make','app'],cwd=root,check=True)
result=subprocess.run(['./app'],cwd=root,capture_output=True,text=True,check=True)
assert result.stdout.strip()=='1',result.stdout
print('A_HEADERFLOW_BEHAVIOR=PASS')
