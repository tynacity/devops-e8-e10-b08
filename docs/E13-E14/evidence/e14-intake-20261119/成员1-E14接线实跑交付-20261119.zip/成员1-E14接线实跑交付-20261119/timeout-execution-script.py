from pathlib import Path
import subprocess,json,time,uuid,hashlib
r=Path('/Users/zhengkanglin/学习/大三上/Devops/第七次上机/成员1-E14真实接线彩排');d=r/'data/headerflow';w=r/'work/e14-timeout-01';marker='AC4_'+uuid.uuid4().hex
c=(d/'candidate.Dockerfile').read_text().replace('RUN make app','RUN python3 -c "import time; time.sleep(120)" '+marker+'\nRUN make app');(d/'candidate-C4.Dockerfile').write_text(c);req=json.loads((d/'HeaderFlow-e14.json').read_text());req.update(candidate='/course/data/headerflow/candidate-C4.Dockerfile',build_timeout=12);(d/'request-C4.json').write_text(json.dumps(req,indent=2))
p=subprocess.Popen(['python3',str(r/'labs/e13e14/orchestrate.py'),'--request',str(d/'request-C4.json'),'--out',str(w)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
probe="import pathlib,json; print(json.dumps([{'pid':p.name,'cmd':(p/'cmdline').read_bytes().decode(errors='replace')} for p in pathlib.Path('/proc').iterdir() if p.name.isdigit() and (p/'cmdline').exists() and b'"+marker+"' in (p/'cmdline').read_bytes().split(bytes([0]))]))"
def scan():
 x=subprocess.run(['docker','run','--rm','--privileged','--pid=host','--user','0','course-e11e12:241880528','python3','-c',probe],capture_output=True,text=True);assert x.returncode==0;return json.loads(x.stdout)
seen=[]
while p.poll() is None:
 x=scan()
 if x:seen.append(x)
 time.sleep(.5)
console=p.communicate()[0];time.sleep(3);after=scan();result=json.loads((w/'result.json').read_text());inner=json.loads((w/'draft-build/result.json').read_text());proof={'marker':marker,'observed_running':seen,'after':after,'host_exit':p.returncode,'outer_status':result['status'],'outer_error':result.get('error'),'inner_status':inner['status'],'candidate_sha256':hashlib.sha256(c.encode()).hexdigest(),'injection':'added RUN sleep before original make; original candidate preserved','console':console};(w/'process-proof.json').write_text(json.dumps(proof,indent=2));print(json.dumps(proof));assert seen and not after and inner['status']=='TIMED_OUT' and p.returncode==1
