int helper(void){int offset=0;return offset;}
