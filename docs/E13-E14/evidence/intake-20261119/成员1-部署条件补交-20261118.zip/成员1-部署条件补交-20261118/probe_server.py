import socket,subprocess,json,platform
ports={}
for port in range(18181,18185):
 s=socket.socket()
 try:s.bind(('127.0.0.1',port));ports[str(port)]='available_at_probe_time'
 except OSError as e:ports[str(port)]=str(e)
 finally:s.close()
r={'platform':platform.platform(),'machine':platform.machine(),'ports':ports}
for name,args in [('docker',['docker','version']),('images',['docker','image','ls','--no-trunc']),('containers',['docker','ps','--format','{{.Names}} {{.Ports}}'])]:
 p=subprocess.run(args,capture_output=True,text=True);r[name]={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
print(json.dumps(r,indent=2))
